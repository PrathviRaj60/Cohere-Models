import streamlit as st
import random
import requests

# Generate random emoji background
def generate_emoji_background():
    emojis = ['🌟', '🎉', '🌸', '☕', '🚀', '🍕', '💡', '🌈']
    background = "".join(random.choice(emojis) for _ in range(1000))
    return f"""
    <div style="
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -1;
        font-size: 25px;
        line-height: 1.2;
        white-space: pre-wrap;
        opacity: 0.2;
        overflow: hidden;
    ">
        {background}
    </div>
    """

# Function to call text-to-video API (example for concept)
def generate_video_from_text(input_text):
    # Replace with your API URL and key
    api_url = "https://api.cohere.ai/generate"
    api_key = "RzWMNercdb7YX2sEYlJwetX5jHWINcBmX0PSN2Sm"  # Replace with actual API key

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    data = {
        "prompt": input_text,
        "resolution": "1920x1080",
        "duration": 10,  # Example: 10 seconds video
    }

    response = requests.post(api_url, json=data, headers=headers)
    if response.status_code == 200:
        video_url = response.json().get("video_url")
        return video_url
    else:
        raise Exception(f"Error: {response.status_code} - {response.text}")

# Set up Streamlit interface
st.set_page_config(page_title="Text-to-Video Generator", layout="centered")

# Display emoji background
st.markdown(generate_emoji_background(), unsafe_allow_html=True)

# Streamlit interface
st.title("Text-to-Video Generator 🎥")
st.write("Enter your idea, and we'll generate a video!")

# Input text
input_text = st.text_input("Enter your video idea:")

# Generate button
if st.button("Generate Video"):
    if input_text.strip():
        st.info("Generating your video... 🚀")
        
        try:
            video_url = generate_video_from_text(input_text)
            st.success("Video generated successfully!")
            st.video(video_url)  # Display video in Streamlit
        except Exception as e:
            st.error(f"Error generating video: {e}")
    else:
        st.error("Please enter a valid idea.")
