import streamlit as st
from cohere import Client

# Directly provide the Cohere API key
COHERE_API_KEY = "RzWMNercdb7YX2sEYlJwetX5jHWINcBmX0PSN2Sm"
cohere_client = Client(COHERE_API_KEY)

## Streamlit UI Setup
st.set_page_config(page_title="Conversational Q&A Chatbot")
st.header("Hey, Let's Chat")

# Initialize session state for storing the conversation history
if 'flowmessages' not in st.session_state:
    st.session_state['flowmessages'] = [
        {"role": "system", "content": "You are a comedian AI assistant"}
    ]

# Function to get response from Cohere's API based on the conversation history
def get_chatmodel_response(question):
    # Append the user's question to the conversation history
    st.session_state['flowmessages'].append({"role": "user", "content": question})

    # Prepare the conversation history for Cohere's API as a prompt
    conversation = ""
    for msg in st.session_state['flowmessages']:
        conversation += f"{msg['role'].capitalize()}: {msg['content']}\n"

    # Use Cohere's generate method for response generation
    response = cohere_client.generate(
        model="command",  # You can change this to another model size if needed
        prompt=conversation,
        max_tokens=150,  # Control response length
        temperature=0.7  # Adjust creativity
    )

    # Get the assistant's response and append it to the conversation
    assistant_response = response.generations[0].text.strip()
    st.session_state['flowmessages'].append({"role": "assistant", "content": assistant_response})

    return assistant_response

# Input field for the user to ask questions
input_text = st.text_input("Input: ", key="input")

# Submit button
submit = st.button("Ask the question")

# Get the response from the chat model
if submit and input_text:
    response = get_chatmodel_response(input_text)
    st.subheader("The Response is:")
    st.write(response)